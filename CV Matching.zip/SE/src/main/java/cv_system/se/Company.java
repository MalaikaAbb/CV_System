package cv_system.se;
import java.util.Scanner;

public class Company {
    private String companyName;
    private String field;
    private int numOfEmployees;

    private String CID;
    public Company() {
        // default constructor
    }

    public Company(String companyName, String field, int numOfEmployees) {
        this.companyName = companyName;
        this.field = field;
        this.numOfEmployees = numOfEmployees;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setField(String field) {
        this.field = field;
    }

    public void setNumOfEmployees(int numOfEmployees) {
        this.numOfEmployees = numOfEmployees;
    }

    public void setCompanyID(String id) {
        this.CID = id;
    }

    /*public void setCompanyDetails() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter company name: ");
        String companyName = scanner.nextLine();
        setCompanyName(companyName);

        System.out.print("Enter field: ");
        String field = scanner.nextLine();
        setField(field);

        System.out.print("Enter Company ID: ");
        int ID = scanner.nextInt();
        setCompanyID(ID);

        System.out.print("Enter number of employees: ");
        int numOfEmployees = scanner.nextInt();
        setNumOfEmployees(numOfEmployees);
    }*/

    // getters for the variables
    public String getCompanyName() {
        return companyName;
    }

    public String getField() {
        return field;
    }

    public int getNumOfEmployees() {
        return numOfEmployees;
    }

    public String getCompanyID() {
        return CID;
    }
}

