package cv_system.se;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

//import javax.swing.*;
import java.io.IOException;
import java.sql.*;
import java.util.Objects;

public class MainController {

    public static Candidate candidate= new Candidate();
    public static Company company= new Company();
    public static Questionnaire questionnaire= new Questionnaire();
    @FXML
    private Button loginButton= new Button();

    @FXML
    private Button registerButton= new Button();

    @FXML
    private Button registerPortalCandidate = new Button();
    @FXML
    private Button registerPortalCompany = new Button();
    @FXML
    private Button loginPortalCandidate = new Button();
    @FXML
    private Button loginPortalCompany = new Button();
    @FXML
    private TextField candidateCnicTF = new TextField();
    @FXML
    private TextField candidateNameTF = new TextField();
    @FXML
    private TextField candidateGenderTF = new TextField();
    @FXML
    private TextField candidateAgeTF = new TextField();

    @FXML
    private Label candidateRegisterMessage = new Label();

    @FXML
    private TextField companyIdTF = new TextField();
    @FXML
    private TextField companyNameTF = new TextField();
    @FXML
    private TextField companyFieldTF = new TextField();
    @FXML
    private TextField companyCountTF = new TextField();
    @FXML
    private Label companyRegisterMessage = new Label();

    @FXML
    private Button canLoginButton= new Button();

    @FXML
    private TextField canLoginNameTF = new TextField();
    @FXML
    private TextField canLoginCnicTF = new TextField();
    //private JInternalFrame stage;
    @FXML
    private Label candidateHomeLabel;

    @FXML
    private Button questionnaireButton;

    @FXML
    private Button uploadCVButton;

    @FXML
    private RadioButton extroYes;
    @FXML
    private RadioButton extroNo;
    @FXML
    private RadioButton creativeYes;
    @FXML
    private RadioButton creativeNo;
    @FXML
    private RadioButton unconvYes;
    @FXML
    private RadioButton unconvNo;
    @FXML
    private RadioButton hardYes;
    @FXML
    private RadioButton hardNo;
    @FXML
    private RadioButton deskYes;
    @FXML
    private RadioButton deskNo;
    @FXML
    private RadioButton overtimeYes;
    @FXML
    private RadioButton overtimeNo;
    @FXML
    private RadioButton improvYes;
    @FXML
    private RadioButton improvNo;
    @FXML
    private RadioButton newEnvYes;
    @FXML
    private RadioButton newEnvNo;
    @FXML
    private Button questionnaireSubmit;
    @FXML
    private Label questionnaireSubmitMessage;
    @FXML
    private TextField compLoginIdTF;
    @FXML
    private TextField compLoginNameTF;
    @FXML
    private Button compLoginButton;
    @FXML
    private Label companyHomeLabel;
    @FXML
    private Button canRecPortal;
    @FXML
    private Button searchWebDev;
    @FXML
    private Button searchDataAn;
    @FXML
    private Button searchManager;
    @FXML
    private Button searchChiefStrategyOfficer;
    @FXML
    private Button searchEngineers;

    @FXML
    private TableView<CV_Info> table;
    @FXML
    private TableColumn<CV_Info, String> cnicTable;
    @FXML
    private TableColumn<CV_Info, String> nameTable;
    @FXML
    private TableColumn<CV_Info, String> genderTable;
    @FXML
    private TableColumn<CV_Info, String> educationTable;
    @FXML
    private TableColumn<CV_Info, String> experienceTable;
    @FXML
    private TableColumn<CV_Info, Integer> yearsTable;
    @FXML
    private TableColumn<CV_Info, String> projectsTable;
    @FXML
    private TableColumn<CV_Info, String> emailTable;
    @FXML
    private TableColumn<CV_Info, String> domainTable;
    @FXML
    private TableColumn<CV_Info, String> cgpaTable;
    @FXML
    private TableColumn<CV_Info, String> skill1Table;
    @FXML
    private TableColumn<CV_Info, String> skill2Table;
    @FXML
    private Label candidateReturnHome;
    @FXML
    private Label companyReturnHome;
    @FXML
    private Label signOutLabel;
    @FXML
    private Button giveFeedback;
    @FXML
    private Button submitFeedback;
    @FXML
    private TextField empCnicTF;
    @FXML
    private TextField empNameTF;
    @FXML
    private TextField empFeedbackTF;
    @FXML
    private Label feedbackMessageLabel;
    @FXML
    private Button SubUploadCV;
    @FXML
    private Label SubmitCVMessage;

    @FXML
    private Label loginMessage;
    @FXML
    private TextField educationTF;
    @FXML
    private TextField experienceTF;
    @FXML
    private TextField yearsTF;
    @FXML
    private TextField projectsTF;
    @FXML
    private TextField domainTF;
    @FXML
    private TextField universityTF;
    @FXML
    private TextField cgpaTF;
    @FXML
    private TextField skill1TF;
    @FXML
    private TextField skill2TF;
    @FXML
    private TextField skill3TF;
    @FXML
    private TextField language1TF;
    @FXML
    private TextField language2TF;
    @FXML
    private Button checkFeedbackButton;
    @FXML
    private TableView<Feedback> tableFeedback;
    @FXML
    private  TableColumn<Feedback, String> compNameTable;
    @FXML
    private  TableColumn<Feedback, String> compFeedbackTable;
    @FXML
    private Button viewQuestionnaireButton;
    @FXML
    private Button questCheckButton;
    @FXML
    private TextField questCheckTF;
    @FXML
    private Label questCheckMessage;
    @FXML
    private Label extrovertedLabel;
    @FXML
    private Label creativeLabel;
    @FXML
    private Label unconvLabel;
    @FXML
    private Label hardworkLabel;
    @FXML
    private Label deskJobLabel;
    @FXML
    private Label overtimeLabel;
    @FXML
    private Label improvLabel;
    @FXML
    private Label newEnvLabel;
    @FXML
    private Label questCnicLabel;


    //===================================== MAIN WELCOME PAGE FUNC ===========================================================
    public void registerButtonOnAction(ActionEvent a) throws IOException
    {
        Parent root = FXMLLoader.load(getClass().getResource("registerPortal.fxml"));
        Stage window= (Stage)registerButton.getScene().getWindow();
        window.setScene(new Scene(root, 600,400));
    }

    public void loginButtonOnAction(ActionEvent a) throws IOException
    {
        Parent root = FXMLLoader.load(getClass().getResource("loginPortal.fxml"));
        Stage window= (Stage)loginButton.getScene().getWindow();
        window.setScene(new Scene(root, 600,400));
    }


    //===================================== REGISTER AND LOGIN PORTAL FUNC ===========================================================
    public void registerPortalCandidateButtonOnAction(ActionEvent a) throws IOException
    {
        Parent root = FXMLLoader.load(getClass().getResource("candidateRegistration.fxml"));
        Stage window= (Stage)registerPortalCandidate.getScene().getWindow();
        window.setScene(new Scene(root, 600,400));
    }

    public void RegisterPortalCompanyButtonOnAction(ActionEvent a) throws IOException
    {
        Parent root = FXMLLoader.load(getClass().getResource("companyRegistration.fxml"));
        Stage window= (Stage)registerPortalCompany.getScene().getWindow();
        window.setScene(new Scene(root, 600,400));
    }

    public void setRegisterCandidateOnAction(ActionEvent a) throws IOException, SQLException {
        String CNIC= candidateCnicTF.getText();
        String name= candidateNameTF.getText();
        String age= candidateAgeTF.getText();
        String gender= candidateGenderTF.getText();

        DatabaseConnection connect= new DatabaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();
        String query=("SELECT COUNT(1) FROM cv.candidate WHERE CNIC=" + CNIC + ";");
        ResultSet rs=st.executeQuery(query);

        rs.next();

        if(rs.getInt(1)==1)
        {
            candidateRegisterMessage.setText("User already exists, please try again");
        }
        else if(rs.getInt(1)==0)
        {
            String insert = " insert into cv.candidate (CNIC, CName, gender, age)"
                    + " values (?, ?, ?, ?)";
            PreparedStatement preparedStmt = connectDB.prepareStatement(insert);
            preparedStmt.setString (1, CNIC);
            preparedStmt.setString (2, name);
            preparedStmt.setString(3, gender);
            preparedStmt.setString(4, age);

            // execute the preparedstatement
            preparedStmt.execute();
            candidateRegisterMessage.setText("Successfully Registered!");
        }

    }

    public void LoginPortalCandidateOnAction(ActionEvent a) throws IOException
    {
        Parent root = FXMLLoader.load(getClass().getResource("candidateLogin.fxml"));
        Stage window= (Stage)loginPortalCandidate.getScene().getWindow();
        window.setScene(new Scene(root, 600,400));
    }

    public void setRegisterCompanyOnAction(ActionEvent a) throws IOException, SQLException {
        String ID= companyIdTF.getText();
        String name= companyNameTF.getText();
        String field= companyFieldTF.getText();
        String empCount= companyCountTF.getText();

        DatabaseConnection connect= new DatabaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();
        String query=("SELECT COUNT(1) FROM cv.company WHERE CID=" + ID + ";");
        ResultSet rs=st.executeQuery(query);

        rs.next();

        if(rs.getInt(1)==1)
        {
            companyRegisterMessage.setText("User already exists, please try again");
        }

        else if(rs.getInt(1)==0)
        {
            String insert = " insert into cv.company (CID, CName, field, No_of_Employees)"
                    + " values (?, ?, ?, ?)";
            PreparedStatement preparedStmt = connectDB.prepareStatement(insert);
            preparedStmt.setString (1, ID);
            preparedStmt.setString (2, name);
            preparedStmt.setString(3, field);
            preparedStmt.setString(4, empCount);

            // execute the preparedstatement
            preparedStmt.execute();
            companyRegisterMessage.setText("Successfully Registered!");
        }

    }

    public void candidateLoginButtonOnAction(ActionEvent a) throws IOException, SQLException
    {
        String Cnic=canLoginCnicTF.getText();
        String name=canLoginNameTF.getText();

        DatabaseConnection connect= new DatabaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String loginAttempt=("SELECT COUNT(1) FROM cv.candidate WHERE CNIC='" + Cnic + "' AND CName='" + name + "';");
        ResultSet rs=st.executeQuery(loginAttempt);

        rs.next();

        if(rs.getInt(1)==1)
        {
            String query  = "select * from candidate WHERE CNIC ='"+Cnic+"' AND CName ='"+ name +"'";
            ResultSet res=st.executeQuery(query);
            if(res.next())
            {
                String gen=res.getString("gender");
                int age=res.getInt("age");
                candidate.setName(name);
                candidate.setAge(age);
                candidate.setGender(gen);
                candidate.setCNIC(Cnic);

                Stage stage = (Stage) canLoginButton.getScene().getWindow();
                stage.close();

                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("candidateHomePage.fxml"));
                Parent root = fxmlLoader.load();
                Scene scene = new Scene(root, 680, 425);
                MainController cpc=fxmlLoader.getController();

                cpc.candidateHomeLabel.setText(name);
                //cpc.LibrarianID.setText(id);

                stage.setTitle("Candidate Home Page");
                stage.setScene(scene);
                stage.show();
            }
        }
        else if(rs.getInt(1)==0)
        {
            loginMessage.setText("Sorry, you entered invalid details");
        }
    }

    //===================================== CANDIDATE FUNCTIONALITY ===========================================================
    public void questionnaireButtonOnAction(ActionEvent a) throws IOException
    {
        Parent root = FXMLLoader.load(getClass().getResource("Questionnaire.fxml"));
        Stage window= (Stage)questionnaireButton.getScene().getWindow();
        window.setScene(new Scene(root, 700,540));
    }

    public void questionnaireSubmitButtonOnAction(ActionEvent a) throws IOException, SQLException
    {
        Boolean extrovertedYes= extroYes.isSelected();
        Boolean extrovertedNo= extroNo.isSelected();
        Boolean CreativeYes= creativeYes.isSelected();
        Boolean CreativeNo= creativeNo.isSelected();
        Boolean unconventionYes= unconvYes.isSelected();
        Boolean unconventionNo= unconvNo.isSelected();
        Boolean hardworkYes= hardYes.isSelected();
        Boolean hardworkNo= hardNo.isSelected();
        Boolean deskJobYes= deskYes.isSelected();
        Boolean deskJobNo= deskNo.isSelected();
        Boolean OvertimeYes= overtimeYes.isSelected();
        Boolean OvertimeNo= overtimeNo.isSelected();
        Boolean improvisationYes=improvYes.isSelected();
        Boolean improvisationNo=improvNo.isSelected();
        Boolean NewEnvYes=newEnvYes.isSelected();
        Boolean NewEnvNo= newEnvNo.isSelected();
        Boolean validityCheckNotFilled=false, validityCheckFilledTwo=false;

        String extroverted = null, creative= null, unconventional=null, hardworking=null;
        String desk=null, overtime=null, improv=null, newEnv=null;

        //Catering the case if two neither of the options are selected

        if(!extrovertedYes && !extrovertedNo)
        {
            questionnaireSubmitMessage.setText("You have left one or more of the fields empty, please choose ONE");
        }
        else if(!CreativeYes && !CreativeNo)
        {
            questionnaireSubmitMessage.setText("You have left one or more of the fields empty, please choose ONE");
        }
        else if(!unconventionYes && !unconventionNo)
        {
            questionnaireSubmitMessage.setText("You have left one or more of the fields empty, please choose ONE");
        }
        else if(!hardworkYes && !hardworkNo)
        {
            questionnaireSubmitMessage.setText("You have left one or more of the fields empty, please choose ONE");
        }
        else if(!deskJobYes && !deskJobNo)
        {
            questionnaireSubmitMessage.setText("You have left one or more of the fields empty, please choose ONE");
        }
        else if(!improvisationYes && !improvisationNo)
        {
            questionnaireSubmitMessage.setText("You have left one or more of the fields empty, please choose ONE");
        }
        else if(!OvertimeYes && !OvertimeNo)
        {
            questionnaireSubmitMessage.setText("You have left one or more of the fields empty, please choose ONE");
        }
        else if(!NewEnvYes && !NewEnvNo)
        {
            questionnaireSubmitMessage.setText("You have left one or more of the fields empty, please choose ONE");
        }
        else
        {
            validityCheckNotFilled=true;
        }

        //Catering the case if both of the options are selected

        if(extrovertedYes && extrovertedNo)
        {
            questionnaireSubmitMessage.setText("You have selected multiple options for one or more categories, please choose ONE");
        }
        else if(CreativeYes && CreativeNo)
        {
            questionnaireSubmitMessage.setText("You have selected multiple options for one or more categories, please choose ONE");
        }
        else if(unconventionYes && unconventionNo)
        {
            questionnaireSubmitMessage.setText("You have selected multiple options for one or more categories, please choose ONE");
        }
        else if(hardworkYes && hardworkNo)
        {
            questionnaireSubmitMessage.setText("You have selected multiple options for one or more categories, please choose ONE");
        }
        else if(deskJobYes && deskJobNo)
        {
            questionnaireSubmitMessage.setText("You have selected multiple options for one or more categories, please choose ONE");
        }
        else if(improvisationYes && improvisationNo)
        {
            questionnaireSubmitMessage.setText("You have selected multiple options for one or more categories, please choose ONE");
        }
        else if(OvertimeYes && OvertimeNo)
        {
            questionnaireSubmitMessage.setText("You have selected multiple options for one or more categories, please choose ONE");
        }
        else if(NewEnvYes && NewEnvNo)
        {
            questionnaireSubmitMessage.setText("You have selected multiple options for one or more categories, please choose ONE");
        }
        else
        {
            validityCheckFilledTwo=true;
        }

        if(validityCheckFilledTwo && validityCheckNotFilled)
        {
            if(extrovertedYes)
            {
                extroverted="Yes";
            }
            else if(extrovertedNo)
            {
                extroverted="No";
            }

            if(CreativeYes)
            {
                creative="Yes";
            }
            else if(CreativeNo)
            {
                creative="No";
            }

            if(unconventionYes)
            {
                unconventional="Yes";
            }
            else if(unconventionNo)
            {
                unconventional="No";
            }

            if(hardworkYes)
            {
                hardworking="Yes";
            }
            else if(hardworkNo)
            {
                hardworking="No";
            }

            if(deskJobYes)
            {
                desk="Yes";
            }
            else if(deskJobNo)
            {
                desk="No";
            }

            if(OvertimeYes)
            {
                overtime="Yes";
            }
            else if(OvertimeNo)
            {
                overtime="No";
            }

            if(improvisationYes)
            {
                improv="Yes";
            }
            else if(improvisationNo)
            {
                improv="No";
            }

            if(NewEnvYes)
            {
                newEnv="Yes";
            }
            else if(NewEnvNo)
            {
                newEnv="No";
            }

            DatabaseConnection connect= new DatabaseConnection();
            Connection connectDB= connect.getConnection();

            Statement st= connectDB.createStatement();

            String check=("SELECT COUNT(1) FROM cv.questionnaire WHERE CNIC='" + candidate.getCNIC() + "';");

            ResultSet rs=st.executeQuery(check);

            rs.next();

            if(rs.getInt(1)==1)
            {
                String del="delete from cv.questionnaire where CNIC= " + candidate.getCNIC() + ";";
                PreparedStatement stmt = connectDB.prepareStatement(del);
                stmt.executeUpdate();
            }
            String insert = " insert into cv.questionnaire (cnic, Extroverted, Creative, UnconventionalSolution, Hardwork, DeskJob, Overtime, Improvisation, NewEnv)"
                    + " values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStmt = connectDB.prepareStatement(insert);
            preparedStmt.setString (1, candidate.getCNIC());
            preparedStmt.setString (2, extroverted);
            preparedStmt.setString(3, creative);
            preparedStmt.setString(4, unconventional);
            preparedStmt.setString(5, hardworking);
            preparedStmt.setString(6, desk);
            preparedStmt.setString(7, overtime);
            preparedStmt.setString(8, improv);
            preparedStmt.setString(9, newEnv);

            // execute the preparedstatement
            preparedStmt.execute();

            questionnaireSubmitMessage.setText("Submitted Successfully!");
        }
    }

    public void uploadCVButtonOnAction(ActionEvent a) throws IOException
    {
        Parent root = FXMLLoader.load(getClass().getResource("uploadCV.fxml"));
        Stage window= (Stage)uploadCVButton.getScene().getWindow();
        window.setScene(new Scene(root, 900,650));
    }

    public void submitCVOnAction(ActionEvent a) throws IOException, SQLException
    {
        String education= educationTF.getText();
        String experience= experienceTF.getText();
        String years= yearsTF.getText();
        String projects= projectsTF.getText();
        String domain= domainTF.getText();
        String uni= universityTF.getText();
        String cgpa= cgpaTF.getText();
        String skill1= skill1TF.getText();
        String skill2= skill2TF.getText();
        String skill3= skill3TF.getText();
        String lang1= language1TF.getText();
        String lang2= language2TF.getText();

        DatabaseConnection connect= new DatabaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("SELECT COUNT(1) FROM cv.cv_info WHERE cnic=" + candidate.getCNIC() + ";");
        ResultSet rs=st.executeQuery(query);

        rs.next();

        if(rs.getInt(1)==1)
        {
            String del="delete from cv.cv_info where cnic= " + candidate.getCNIC() + ";";
            PreparedStatement stmt = connectDB.prepareStatement(del);
            stmt.executeUpdate();
        }

        query="INSERT INTO cv_info (cnic, name, gender, age, id, education, experience, years_of_experience, projects, domain, university, cgpa, skill1, skill2, skill3, language1, language2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement stmt = connectDB.prepareStatement(query);
        stmt.setString(1, candidate.getCNIC());
        stmt.setString(2, candidate.getName());
        stmt.setString(3, candidate.getGender());
        stmt.setInt(4, candidate.getAge());
        stmt.setInt(5, 1000);
        stmt.setString(6, education);
        stmt.setString(7, experience);
        stmt.setString(8, years);
        stmt.setString(9, projects);
        stmt.setString(10, domain);
        stmt.setString(11, uni);
        stmt.setString(12, cgpa);
        stmt.setString(13, skill1);
        stmt.setString(14, skill2);
        stmt.setString(15, skill3);
        stmt.setString(16, lang1);
        stmt.setString(17, lang2);

        stmt.executeUpdate();

        SubmitCVMessage.setText("Information Uploaded Successfully!");
    }

    public void checkFeedbackButtonOnAction(ActionEvent a) throws IOException, SQLException {
        Stage stage = (Stage) checkFeedbackButton.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("checkFeedback.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainController cpc=fxmlLoader.getController();
        DatabaseConnection connect= new DatabaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query="select feedback, CompanyName from feedback WHERE candidateCNIC ='"+candidate.getCNIC()+"' AND CandidateName ='"+ candidate.getName() +"'";
        ResultSet rs=st.executeQuery(query);

        cpc.compNameTable.setCellValueFactory(new PropertyValueFactory<Feedback, String>("companyName"));
        cpc.compFeedbackTable.setCellValueFactory(new PropertyValueFactory<Feedback, String>("feedback"));

        while(rs.next())
        {
            Feedback feed= new Feedback();
            feed.setCompanyName(rs.getString("CompanyName"));
            feed.setFeedback(rs.getString("feedback"));
            cpc.tableFeedback.getItems().addAll(feed);
        }

        stage.setTitle("View Feedback");
        stage.setScene(scene);
        stage.show();
    }

    public void candidateReturnHome(javafx.scene.input.MouseEvent mouseEvent) throws IOException
    {
        Stage stage = (Stage) candidateReturnHome.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("candidateHomePage.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainController cpc=fxmlLoader.getController();
        cpc.candidateHomeLabel.setText(candidate.getName());

        stage.setTitle("Candidate Portal");
        stage.setScene(scene);
        stage.show();
    }

    //===================================== COMPANY FUNCTIONALITY ===========================================================
    public void LoginPortalCompanyButtonOnAction(ActionEvent a) throws IOException
    {
        Parent root = FXMLLoader.load(getClass().getResource("companyLogin.fxml"));
        Stage window= (Stage)loginPortalCompany.getScene().getWindow();
        window.setScene(new Scene(root, 600,400));
    }
    public void companyLoginButtonOnAction(ActionEvent a) throws IOException, SQLException
    {
        String id=compLoginIdTF.getText();
        String name=compLoginNameTF.getText();

        DatabaseConnection connect= new DatabaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String loginAttempt=("SELECT COUNT(1) FROM cv.company WHERE CID='" + id + "' AND CName='" + name + "';");
        //PreparedStatement preparedStmt = connectDB.prepareStatement(loginAttempt);

        ResultSet rs=st.executeQuery(loginAttempt);

        rs.next();

        if(rs.getInt(1)==1)
        {
            String query  = "SELECT * FROM cv.company WHERE CID='" + id + "' AND CName='" + name + "';";
            ResultSet res=st.executeQuery(query);
            if(res.next())
            {
                String field=res.getString("field");
                int num=res.getInt("No_of_Employees");
                company.setCompanyName(name);
                company.setCompanyID(id);
                company.setField(field);
                company.setNumOfEmployees(num);

                Stage stage = (Stage) compLoginButton.getScene().getWindow();
                stage.close();

                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("companyHomePage.fxml"));
                Parent root = fxmlLoader.load();
                Scene scene = new Scene(root, 720, 440);
                MainController cpc=fxmlLoader.getController();

                cpc.companyHomeLabel.setText(name);
                //cpc.LibrarianID.setText(id);

                stage.setTitle("Company Home Page");
                stage.setScene(scene);
                stage.show();
            }
        }
        else if(rs.getInt(1)==0)
        {
            loginMessage.setText("Sorry, you entered invalid details");
        }
    }

    public void candidateRecommendationPortalButtonOnAction(ActionEvent a) throws IOException
    {
        Parent root = FXMLLoader.load(getClass().getResource("candidateRec1_positionSelect.fxml"));
        Stage window= (Stage)canRecPortal.getScene().getWindow();
        window.setScene(new Scene(root, 640,530));
    }

    public void searchWebDevButtonOnAction(ActionEvent a) throws IOException, SQLException {
        Stage stage = (Stage) searchWebDev.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("searchWebDev.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainController cpc=fxmlLoader.getController();
        DatabaseConnection connect= new DatabaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select * from cv.cv_info inner join cv.questionnaire on cv.cv_info.cnic=cv.questionnaire.CNIC");
        ResultSet rs=st.executeQuery(query);

        cpc.cnicTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("CNIC"));
        cpc.nameTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("name"));
        cpc.genderTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("gender"));
        cpc.educationTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("education"));
        cpc.experienceTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("experience"));
        cpc.yearsTable.setCellValueFactory(new PropertyValueFactory<CV_Info, Integer>("years_of_experience"));
        cpc.projectsTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("projects"));
        cpc.emailTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("email"));
        cpc.domainTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("domain"));
        cpc.cgpaTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("cgpa"));
        cpc.skill1Table.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("skill1"));
        cpc.skill2Table.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("skill2"));

        while(rs.next())
        {
            CV_Info cv= new CV_Info();
            cv.setCNIC(rs.getString("cnic"));
            cv.setName(rs.getString("name"));
            cv.setAge(rs.getInt("age"));
            cv.setGender(rs.getString("gender"));
            cv.setEducation(rs.getString("education"));
            cv.setExperience(rs.getString("experience"));
            cv.setYears_of_experience(rs.getInt("years_of_experience"));
            cv.setProjects(rs.getString("projects"));
            cv.setEmail("abc@gmail.com");
            cv.setDomain(rs.getString("domain"));
            cv.setCgpa(rs.getFloat("cgpa"));
            cv.setSkill1(rs.getString("skill1"));
            cv.setSkill2(rs.getString("skill2"));
            //String dom=rs.getString("domain");


            Questionnaire quest= new Questionnaire();
            quest.setCreative(rs.getString("Creative"));
            quest.setHardwork(rs.getString("Hardwork"));

            if(Objects.equals(cv.getDomain(), "Web Development"))
            {
                if(Objects.equals(quest.getCreative(), "Yes") && Objects.equals(quest.getHardwork(), "No"))
                {
                    cpc.table.getItems().addAll(cv);
                }
            }

        }

        stage.setTitle("Web Dev Recs");
        stage.setScene(scene);
        stage.show();
    }
    public void searchDataAnalystButtonOnAction(ActionEvent a) throws IOException, SQLException {
        Stage stage = (Stage) searchDataAn.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("searchDataAnalyst.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainController cpc=fxmlLoader.getController();
        DatabaseConnection connect= new DatabaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select * from cv.cv_info inner join cv.questionnaire on cv.cv_info.cnic=cv.questionnaire.CNIC");
        ResultSet rs=st.executeQuery(query);

        cpc.cnicTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("CNIC"));
        cpc.nameTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("name"));
        cpc.genderTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("gender"));
        cpc.educationTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("education"));
        cpc.experienceTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("experience"));
        cpc.yearsTable.setCellValueFactory(new PropertyValueFactory<CV_Info, Integer>("years_of_experience"));
        cpc.projectsTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("projects"));
        cpc.emailTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("email"));
        cpc.domainTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("domain"));
        cpc.cgpaTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("cgpa"));
        cpc.skill1Table.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("skill1"));
        cpc.skill2Table.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("skill2"));

        while(rs.next())
        {
            CV_Info cv= new CV_Info();
            cv.setCNIC(rs.getString("cnic"));
            cv.setName(rs.getString("name"));
            cv.setAge(rs.getInt("age"));
            cv.setGender(rs.getString("gender"));
            cv.setEducation(rs.getString("education"));
            cv.setExperience(rs.getString("experience"));
            cv.setYears_of_experience(rs.getInt("years_of_experience"));
            cv.setProjects(rs.getString("projects"));
            cv.setEmail("abc@gmail.com");
            cv.setDomain(rs.getString("domain"));
            cv.setCgpa(rs.getFloat("cgpa"));
            cv.setSkill1(rs.getString("skill1"));
            cv.setSkill2(rs.getString("skill2"));
            //String dom=rs.getString("domain");


            Questionnaire quest= new Questionnaire();
            quest.setUnconventionalSol(rs.getString("UnconventionalSolution"));
            quest.setCreative(rs.getString("Creative"));

            if(Objects.equals(cv.getDomain(), "Data Science"))
            {
                if(Objects.equals(quest.getUnconventionalSol(), "Yes") && Objects.equals(quest.getCreative(), "Yes"))
                {
                    cpc.table.getItems().addAll(cv);
                }
            }

        }

        stage.setTitle("Data Scientist Recs");
        stage.setScene(scene);
        stage.show();
    }
    public void searchManagerButtonOnAction(ActionEvent a) throws IOException, SQLException {
        Stage stage = (Stage) searchManager.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("searchManager.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainController cpc=fxmlLoader.getController();
        DatabaseConnection connect= new DatabaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select * from cv.cv_info inner join cv.questionnaire on cv.cv_info.cnic=cv.questionnaire.CNIC");
        ResultSet rs=st.executeQuery(query);

        cpc.cnicTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("CNIC"));
        cpc.nameTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("name"));
        cpc.genderTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("gender"));
        cpc.educationTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("education"));
        cpc.experienceTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("experience"));
        cpc.yearsTable.setCellValueFactory(new PropertyValueFactory<CV_Info, Integer>("years_of_experience"));
        cpc.projectsTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("projects"));
        cpc.emailTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("email"));
        cpc.domainTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("domain"));
        cpc.cgpaTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("cgpa"));
        cpc.skill1Table.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("skill1"));
        cpc.skill2Table.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("skill2"));

        while(rs.next())
        {
            CV_Info cv= new CV_Info();
            cv.setCNIC(rs.getString("cnic"));
            cv.setName(rs.getString("name"));
            cv.setAge(rs.getInt("age"));
            cv.setGender(rs.getString("gender"));
            cv.setEducation(rs.getString("education"));
            cv.setExperience(rs.getString("experience"));
            cv.setYears_of_experience(rs.getInt("years_of_experience"));
            cv.setProjects(rs.getString("projects"));
            cv.setEmail("abc@gmail.com");
            cv.setDomain(rs.getString("domain"));
            cv.setCgpa(rs.getFloat("cgpa"));
            cv.setSkill1(rs.getString("skill1"));
            cv.setSkill2(rs.getString("skill2"));

            Questionnaire quest= new Questionnaire();
            quest.setExtroverted(rs.getString("Extroverted"));
            quest.setNewEnv(rs.getString("NewEnv"));

            if(Objects.equals(cv.getDomain(), "Management"))
            {
                if(Objects.equals(quest.getExtroverted(), "Yes") && Objects.equals(quest.getNewEnv(), "Yes"))
                {
                    cpc.table.getItems().addAll(cv);
                }
            }

        }

        stage.setTitle("Manager Recs");
        stage.setScene(scene);
        stage.show();
    }
    public void searchCSOButtonOnAction(ActionEvent a) throws IOException, SQLException {
        Stage stage = (Stage) searchChiefStrategyOfficer.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("searchCSO.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainController cpc=fxmlLoader.getController();
        DatabaseConnection connect= new DatabaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select * from cv.cv_info inner join cv.questionnaire on cv.cv_info.cnic=cv.questionnaire.CNIC");
        ResultSet rs=st.executeQuery(query);

        cpc.cnicTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("CNIC"));
        cpc.nameTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("name"));
        cpc.genderTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("gender"));
        cpc.educationTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("education"));
        cpc.experienceTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("experience"));
        cpc.yearsTable.setCellValueFactory(new PropertyValueFactory<CV_Info, Integer>("years_of_experience"));
        cpc.projectsTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("projects"));
        cpc.emailTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("email"));
        cpc.domainTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("domain"));
        cpc.cgpaTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("cgpa"));
        cpc.skill1Table.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("skill1"));
        cpc.skill2Table.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("skill2"));

        while(rs.next())
        {
            CV_Info cv= new CV_Info();
            cv.setCNIC(rs.getString("cnic"));
            cv.setName(rs.getString("name"));
            cv.setAge(rs.getInt("age"));
            cv.setGender(rs.getString("gender"));
            cv.setEducation(rs.getString("education"));
            cv.setExperience(rs.getString("experience"));
            cv.setYears_of_experience(rs.getInt("years_of_experience"));
            cv.setProjects(rs.getString("projects"));
            cv.setEmail("abc@gmail.com");
            cv.setDomain(rs.getString("domain"));
            cv.setCgpa(rs.getFloat("cgpa"));
            cv.setSkill1(rs.getString("skill1"));
            cv.setSkill2(rs.getString("skill2"));

            Questionnaire quest= new Questionnaire();
            quest.setExtroverted(rs.getString("Extroverted"));
            quest.setCreative(rs.getString("Creative"));

            if(Objects.equals(cv.getDomain(), "Marketing"))
            {
                if(Objects.equals(quest.getExtroverted(), "Yes") && Objects.equals(quest.getCreative(), "Yes"))
                {
                    cpc.table.getItems().addAll(cv);
                }
            }

        }

        stage.setTitle("CSO Recs");
        stage.setScene(scene);
        stage.show();
    }
    public void searchEngineerButtonOnAction(ActionEvent a) throws IOException, SQLException {
        Stage stage = (Stage) searchEngineers.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("searchEngineer.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainController cpc=fxmlLoader.getController();
        DatabaseConnection connect= new DatabaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select * from cv.cv_info inner join cv.questionnaire on cv.cv_info.cnic=cv.questionnaire.CNIC");
        ResultSet rs=st.executeQuery(query);

        cpc.cnicTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("CNIC"));
        cpc.nameTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("name"));
        cpc.genderTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("gender"));
        cpc.educationTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("education"));
        cpc.experienceTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("experience"));
        cpc.yearsTable.setCellValueFactory(new PropertyValueFactory<CV_Info, Integer>("years_of_experience"));
        cpc.projectsTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("projects"));
        cpc.emailTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("email"));
        cpc.domainTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("domain"));
        cpc.cgpaTable.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("cgpa"));
        cpc.skill1Table.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("skill1"));
        cpc.skill2Table.setCellValueFactory(new PropertyValueFactory<CV_Info, String>("skill2"));

        while(rs.next())
        {
            CV_Info cv= new CV_Info();
            cv.setCNIC(rs.getString("cnic"));
            cv.setName(rs.getString("name"));
            cv.setAge(rs.getInt("age"));
            cv.setGender(rs.getString("gender"));
            cv.setEducation(rs.getString("education"));
            cv.setExperience(rs.getString("experience"));
            cv.setYears_of_experience(rs.getInt("years_of_experience"));
            cv.setProjects(rs.getString("projects"));
            cv.setEmail("abc@gmail.com");
            cv.setDomain(rs.getString("domain"));
            cv.setCgpa(rs.getFloat("cgpa"));
            cv.setSkill1(rs.getString("skill1"));
            cv.setSkill2(rs.getString("skill2"));

            Questionnaire quest= new Questionnaire();
            quest.setHardwork(rs.getString("Hardwork"));
            quest.setOvertime(rs.getString("Overtime"));

            if(Objects.equals(cv.getDomain(), "Mechanical Engineering") || Objects.equals(cv.getDomain(), "Electrical Engineering") || Objects.equals(cv.getDomain(), "Civil Engineering"))
            {
                if(Objects.equals(quest.getHardwork(), "No") && Objects.equals(quest.getOvertime(), "Yes"))
                {
                    cpc.table.getItems().addAll(cv);
                }
            }

        }

        stage.setTitle("Engineer Recs");
        stage.setScene(scene);
        stage.show();
    }

    public void giveFeedbackButtonOnAction(ActionEvent a) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("giveFeedback.fxml"));
        Stage window= (Stage)giveFeedback.getScene().getWindow();
        window.setScene(new Scene(root, 640,455));
    }

    public void submitFeedbackOnAction(ActionEvent a) throws IOException, SQLException
    {
        String empCnic= empCnicTF.getText();
        String empName= empNameTF.getText();
        String empFeedback=empFeedbackTF.getText();

        DatabaseConnection connect= new DatabaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String query=("select max(id) from cv.feedback");
        ResultSet rs=st.executeQuery(query);
        int ID=0;

        if(rs.next())
        {
            ID=rs.getInt(1);
            ID += 1;
        }

        query="INSERT INTO feedback (id, companyID, candidateCNIC, feedback, CompanyName, CandidateName) VALUES (?,?,?,?,?,?)";
        PreparedStatement stmt = connectDB.prepareStatement(query);
        stmt.setInt(1, ID);
        stmt.setString(2, company.getCompanyID());
        stmt.setString(3, empCnic);
        stmt.setString(4, empFeedback);
        stmt.setString(5, company.getCompanyName());
        stmt.setString(6, empName);

        stmt.execute();

        feedbackMessageLabel.setText("Feedback given successfully!");

    }

    public void viewQuestionnaireButtonOnAction(ActionEvent a) throws IOException
    {
        Parent root = FXMLLoader.load(getClass().getResource("viewRecommendation1.fxml"));
        Stage window= (Stage)viewQuestionnaireButton.getScene().getWindow();
        window.setScene(new Scene(root, 600,400));
    }

    public void questCheckButtonOnAction(ActionEvent a) throws IOException, SQLException {
        candidate.setCNIC(questCheckTF.getText());
        DatabaseConnection connect= new DatabaseConnection();
        Connection connectDB= connect.getConnection();
        Statement st= connectDB.createStatement();

        String loginAttempt=("SELECT COUNT(1) FROM cv.candidate WHERE CNIC='" + candidate.getCNIC() + "';");
        ResultSet rs=st.executeQuery(loginAttempt);

        rs.next();

        if(rs.getInt(1)==0)
        {
            questCheckMessage.setText("The candidate does not exist, please try again");
        }
        else if(rs.getInt(1)==1)
        {

            String query  = "select * from cv.questionnaire WHERE cnic ='"+ candidate.getCNIC() +"'";
            ResultSet res=st.executeQuery(query);

            if(res.next())
            {
                questionnaire.setCNIC(candidate.getCNIC());
                questionnaire.setOvertime(res.getString("Overtime"));
                questionnaire.setHardwork(res.getString("Hardwork"));
                questionnaire.setCreative(res.getString("Creative"));
                questionnaire.setExtroverted(res.getString("Extroverted"));
                questionnaire.setNewEnv(res.getString("NewEnv"));
                questionnaire.setUnconventionalSol(res.getString("UnconventionalSolution"));
                questionnaire.setDeskJob(res.getString("DeskJob"));
                questionnaire.setImprovisation(res.getString("Improvisation"));

                Stage stage = (Stage) questCheckButton.getScene().getWindow();
                stage.close();
                FXMLLoader fxmlLoader = new FXMLLoader();
                fxmlLoader.setLocation(getClass().getResource("viewRecommendation2.fxml"));
                Parent root = fxmlLoader.load();
                Scene scene = new Scene(root, 706, 539);
                MainController cpc=fxmlLoader.getController();

                cpc.extrovertedLabel.setText(questionnaire.getExtroverted());
                cpc.creativeLabel.setText(questionnaire.getCreative());
                cpc.unconvLabel.setText(questionnaire.getUnconventionalSol());
                cpc.hardworkLabel.setText(questionnaire.getHardwork());
                cpc.deskJobLabel.setText(questionnaire.getDeskJob());
                cpc.overtimeLabel.setText(questionnaire.getOvertime());
                cpc.improvLabel.setText(questionnaire.getImprovisation());
                cpc.newEnvLabel.setText(questionnaire.getNewEnv());
                cpc.questCnicLabel.setText(questionnaire.getCNIC());

                stage.setTitle("View Questionnaire Page");
                stage.setScene(scene);
                stage.show();
            }

        }
    }

    public void companyReturnHome(javafx.scene.input.MouseEvent mouseEvent) throws IOException
    {
        Stage stage = (Stage) companyReturnHome.getScene().getWindow();
        stage.close();

        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("companyHomePage.fxml"));
        Parent root = fxmlLoader.load();
        Scene scene = new Scene(root);
        MainController cpc=fxmlLoader.getController();
        cpc.companyHomeLabel.setText(company.getCompanyName());

        stage.setTitle("Company Portal");
        stage.setScene(scene);
        stage.show();
    }
    public void signOutLabelOnMouseClick(javafx.scene.input.MouseEvent mouseEvent) throws IOException
    {
        Parent root = FXMLLoader.load(getClass().getResource("welcomePage.fxml"));
        Stage window= (Stage)signOutLabel.getScene().getWindow();
        window.setScene(new Scene(root, 600,400));
    }
}