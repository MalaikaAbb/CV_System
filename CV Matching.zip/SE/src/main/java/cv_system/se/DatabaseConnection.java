package cv_system.se;
import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {

    public Connection dbLink;

    public Connection getConnection()
    {
        String dbName="cv";
        String dbUser="root";
        String dbPassword="CB97@1004";
        String url="jdbc:mysql://localhost/" + dbName;

        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            dbLink = DriverManager.getConnection(url, dbUser, dbPassword);
        }

        catch (Exception e)
        {
            e.printStackTrace();
        }

        return dbLink;

    }
}
