package cv_system.se;

import java.util.Scanner;
public class Feedback {
    private String companyName;
    private int companyID;
    private String candidateName;

    private String feedback;
    private int candidateCNIC;
    public Feedback()
    {

    }

    public Feedback(String companyName, int companyID, String candidateName, int candidateCNIC) {
        this.companyName = companyName;
        this.companyID = companyID;
        this.candidateName = candidateName;
        this.candidateCNIC = candidateCNIC;
    }


    // getters and setters for the variables
    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getCompanyID() {
        return companyID;
    }

    public void setCompanyID(int companyID) {
        this.companyID = companyID;
    }

    public String getCandidateName() {
        return candidateName;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setCandidateName(String candidateName) {
        this.candidateName = candidateName;
    }

    public int getCandidateCNIC() {
        return candidateCNIC;
    }

    public void setCandidateCNIC(int candidateCNIC) {
        this.candidateCNIC = candidateCNIC;
    }

    public void setFeedback(String feed){feedback=feed;}

    /*public void provideFeedback() {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the company name: ");
        companyName = input.nextLine();

        System.out.print("Enter the company ID: ");
        companyID = input.nextInt();
        input.nextLine();

        System.out.print("Enter the candidate name: ");
        candidateName = input.nextLine();

        System.out.print("Enter the candidate CNIC: ");
        candidateCNIC = input.nextInt();
        input.nextLine();

        System.out.print("Enter your feedback for " + candidateName + ": ");
        feedback = input.nextLine();

    }*/

}
