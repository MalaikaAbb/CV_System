package cv_system.se;

public class Questionnaire {
    private String CNIC;
    private String extroverted;
    private String creative;
    private String unconventionalSol;
    private String hardwork;
    private String deskJob;
    private String overtime;
    private String improvisation;
    private String newEnv;

    public void setCNIC(String cnic) { CNIC=cnic; }
    public void setExtroverted(String result) { extroverted=result; }
    public void setCreative(String result) { creative=result; }
    public void setUnconventionalSol(String result) { unconventionalSol=result; }
    public void setHardwork(String result) { hardwork=result; }
    public void setDeskJob(String result) { deskJob=result; }
    public void setOvertime(String result) { overtime=result; }
    public void setImprovisation(String result) { improvisation=result; }
    public void setNewEnv(String result) { newEnv=result; }

    public String getCNIC(){ return CNIC; }
    public String getExtroverted(){ return extroverted; }
    public String getCreative(){ return creative; }
    public String getUnconventionalSol(){ return unconventionalSol; }
    public String getHardwork(){ return hardwork; }
    public String getDeskJob(){ return deskJob; }
    public String getOvertime(){ return overtime; }
    public String getImprovisation(){ return improvisation; }
    public String getNewEnv(){ return newEnv; }

}
