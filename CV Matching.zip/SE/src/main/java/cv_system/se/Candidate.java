package cv_system.se;
import java.util.Scanner;
public class Candidate {
    private String name;
    private String CNIC;
    private String gender;
    private int id;
    private int age;

    public Candidate()
    {
        //CNIC=0;
    }
    public Candidate(String id, String name, String gender,int age)
    {
        this.CNIC=id;
        this.name=name;
        this.age=age;
        this.gender=gender;
    }

    /*public void setid(String id) {
        this.id = id;
    }*/
    public void setCNIC(String cid) {
        this.CNIC = cid;
    }
    public void setAge(int age) {
        this.age = age;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }


   /* public void RegisterUser() {
        Scanner input = new Scanner(System.in);


        System.out.print("Enter your name: ");
        name = input.nextLine();

        System.out.print("Enter your CNIC number: ");
        CNIC = input.nextInt();
        input.nextLine(); // to consume the newline character left in the input buffer

        System.out.print("Enter your gender: ");
        gender = input.nextLine();

        System.out.print("Enter your ID: ");
        id = input.nextInt();
        input.nextLine();

        System.out.print("Enter your age: ");
        age = input.nextInt();
        input.nextLine();


    }*/

    public String getCNIC() {
        return CNIC;
    }

    public int getAge() {
        return age;
    }

    public String getName() {
        return name;
    }


    public String getGender() {
        return gender;
    }

}

