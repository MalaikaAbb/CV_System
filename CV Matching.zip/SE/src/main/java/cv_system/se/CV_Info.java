package cv_system.se;

import java.util.Scanner;
public class CV_Info {
    private String name;
    private String CNIC;
    private String gender;
    private int age;
    private int id;
    private String education;
    private String experience;
    private int years_of_experience;
    private String projects;
    private String domain;
    private String university;
    private float cgpa;
    private String skill1;

    private String skill2;
    private String skill3;

    private String language1;

    private String language2;
    private String email;

    public CV_Info()
    {
        //CNIC=0;
    }
    public CV_Info(String name, String CNIC, String gender, int age, int id, String education, String experience,
                   int years_of_experience, String projects, String domain, String university, float cgpa,
                   String skill1, String skill2, String skill3, String language1, String language2, String email)
    {
        this.name = name;
        this.CNIC = CNIC;
        this.gender = gender;
        this.age = age;
        this.id = id;
        this.education = education;
        this.experience = experience;
        this.years_of_experience = years_of_experience;
        this.projects = projects;
        this.domain = domain;
        this.university = university;
        this.cgpa = cgpa;
        this.skill1 = skill1;
        this.skill2 = skill2;
        this.skill3 = skill3;
        this.language1 = language1;
        this.language2 = language2;
        this.email=email;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCNIC() {
        return CNIC;
    }

    public void setCNIC(String CNIC) {
        this.CNIC = CNIC;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience;
    }

    public int getYears_of_experience() {
        return years_of_experience;
    }

    public void setYears_of_experience(int years_of_experience) {
        this.years_of_experience = years_of_experience;
    }

    public String getProjects() {
        return projects;
    }

    public void setProjects(String projects) {
        this.projects = projects;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getUniversity() {
        return university;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

    public float getCgpa() {
        return cgpa;
    }

    public void setCgpa(float cgpa) {
        this.cgpa = cgpa;
    }

    public String getSkill1() {
        return skill1;
    }

    public void setSkill1(String skill1) {
        this.skill1 = skill1;
    }

    public String getSkill2() {
        return skill2;
    }

    public void setSkill2(String skill2) {
        this.skill2 = skill2;
    }

    public String getSkill3() {
        return skill3;
    }

    public void setSkill3(String skill3) {
        this.skill3 = skill3;
    }

    public String getLanguage1() {
        return language1;
    }

    public void setLanguage1(String language1) {
        this.language1 = language1;
    }

    public String getLanguage2() {
        return language2;
    }

    public void setLanguage2(String language2) {
        this.language2 = language2;
    }
    public void setEmail(String e){email=e;}
    public String getEmail(){return email;}

   /* public void get_CV_information()
    {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter name: ");
        this.name = scanner.nextLine();

        System.out.print("Enter CNIC: ");
        this.CNIC = scanner.nextInt();
        scanner.nextLine(); // to consume the remaining newline character

        System.out.print("Enter gender (Male/Female): ");
        this.gender = scanner.nextLine();

        System.out.print("Enter age: ");
        this.age = scanner.nextInt();
        scanner.nextLine(); // to consume the remaining newline character

        System.out.print("Enter education: ");
        this.education = scanner.nextLine();

        System.out.print("Enter experience: ");
        this.experience = scanner.nextLine();

        System.out.print("Enter years of experience: ");
        this.years_of_experience = scanner.nextInt();
        scanner.nextLine(); // to consume the remaining newline character

        System.out.print("Enter projects: ");
        this.projects = scanner.nextLine();

        System.out.print("Enter domain: ");
        this.domain = scanner.nextLine();

        System.out.print("Enter university: ");
        this.university = scanner.nextLine();

        System.out.print("Enter CGPA: ");
        this.cgpa = scanner.nextFloat();
        scanner.nextLine(); // to consume the remaining newline character

        System.out.print("Enter skill 1 (if any otherwise enter NONE): ");
        this.skill1 = scanner.nextLine();

        System.out.print("Enter skill 2 (if any otherwise enter NONE): ");
        this.skill2 = scanner.nextLine();

        System.out.print("Enter skill 3 (if any otherwise enter NONE): ");
        this.skill3 = scanner.nextLine();

        System.out.print("Enter language spoken at home: ");
        this.language1 = scanner.nextLine();

        System.out.print("Enter any other language that you can converse in fluently (if any otherwise enter NONE): ");
        this.language2 = scanner.nextLine();


    }*/
}

