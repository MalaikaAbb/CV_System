module cv_system.se {
    requires javafx.controls;
    requires javafx.fxml;

    requires java.sql;
    //requires mysql.connector.java;

    opens cv_system.se to javafx.fxml;
    exports cv_system.se;
}